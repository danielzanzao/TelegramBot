# EnactusBOT

## Overview

EnactusBOT is a Telegram bot designed for Enactus work hours management. The bot provides an interface for team members to register their work hours, access shared resources through the Central Enactus drive, and participate in climate surveys. Built using the Python Telegram Bot library, it features an interactive menu system with inline keyboards for easy navigation and data input.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Architecture
The application follows a modular architecture with clear separation of concerns:

- **Main Bot Class (EnactusBot)**: Centralizes bot initialization, handler setup, and application lifecycle management using the Telegram Bot API
- **Handler System (BotHandlers)**: Implements command handlers, callback query handlers, and message handlers for user interactions
- **Data Layer (DataStorage/BotData)**: Manages in-memory data storage for work hours and user sessions, plus static configuration data

### Data Storage Strategy
Currently implements an in-memory storage solution for MVP purposes:
- **WorkHour DataClass**: Structured data model for work hour entries with member information, task details, and timestamps
- **Reminder DataClass**: Data model for reminder configurations with user mapping, frequency settings, and scheduling information
- **Session Management**: User-specific session storage for maintaining conversation state during multi-step interactions
- **Static Data**: Predefined member lists and configuration stored in the BotData class
- **Reminder Storage**: In-memory storage for active reminder configurations with user association

### User Interaction Flow
The bot implements a specific workflow for work hour registration using inline keyboards:

#### Main Menu Options:
- **📊 Marcar HO**: Initiates work hour registration flow
- **📁 Central Enactus**: Direct link to shared Google Drive
- **📈 Google Sheets**: Access Google Sheets integration and synchronization
- **🔔 Lembretes**: Access reminder management system
- **❓ Ajuda**: Shows help information

#### Work Hour Registration Flow:
1. **Member Selection**: User selects their name from predefined member list
2. **Task Type Selection**: User chooses between "Projeto" (Project) or "Área" (Area)
3. **Project/Area Selection**: 
   - If Project: Shows options "Odoyá", "Mana", "Gelé"
   - If Area: Shows options "DAF", "GP", "MKT", "QLD", "PSD"
4. **Activity Description**: User enters description of work performed
5. **Date Input**: User types date in DD/MM/YYYY format or "hoje" for today
6. **Hours Input**: User types number of hours worked (supports decimals)
7. **Modality Selection**: User chooses between "Presencial" or "EAD"
8. **Confirmation**: User reviews and confirms all data including unique HO ID
9. **Status Assignment**: HO is automatically set to "Pendente" (Pending approval)
10. **Next Action Options**:
    - Mark another HO for same area/project (returns to step 4)
    - Mark HO for different area/project (returns to step 2)
    - Finish with climate survey (shows link to forms)
    - Finish without survey

#### Reminder Management System:
The bot now includes a comprehensive reminder system for automated notifications:

1. **Access Reminder Menu**: Through main menu "🔔 Lembretes" option
2. **Reminder Setup Flow**:
   - Member selection for whom to set reminders
   - Frequency selection: Daily, Weekly, or Monthly
   - Time input in HH:MM format (24h)
   - Confirmation of all settings
3. **Reminder Management Options**:
   - View current reminder details and status
   - Configure new reminder (replaces existing)
   - Disable active reminders
4. **Automated Notifications**: 
   - Background scheduler checks every 5 minutes for due reminders
   - Sends personalized messages encouraging hour tracking
   - Tracks last sent timestamps to prevent spam

#### Manager Approval System:
The bot includes a comprehensive approval workflow for work hour management:

1. **Manager Configuration**: 
   - Managers are configured in `data_models.py` in the `DEFAULT_MANAGERS` section
   - Each manager has a Telegram user ID, name, and list of managed areas/projects
   - Use `/get_my_id` command to discover user IDs for configuration
2. **Approval Workflow**:
   - All new HOs are automatically set to "Pendente" (Pending) status
   - Each HO receives a unique UUID for tracking
   - Managers receive weekly notifications about pending approvals in their areas
3. **Manager Interface**:
   - Weekly automated notifications via Telegram
   - Direct approval/rejection buttons in bot interface
   - Approval history tracking with timestamp and manager name
4. **Status Management**:
   - Three possible statuses: "Pendente", "Aprovado", "Reprovado"
   - Status changes are logged with manager name and timestamp
   - Google Sheets automatically updated with approval information

#### Google Sheets Integration System:
The bot now includes comprehensive Google Sheets integration for data synchronization and management:

1. **Automatic Synchronization**: 
   - Every HO registration is automatically synced to Google Sheets
   - Real-time data backup and accessibility
   - Shows sync status in confirmation messages
2. **Google Sheets Menu Options**:
   - View spreadsheet URL with direct access link
   - Manual bulk synchronization of all stored HO records
   - Connection status and statistics display
3. **Data Structure in Sheets**:
   - Organized columns: Date/Time, Member, Type, Project/Area, Work Date, Hours, Modality, Telegram ID, Status, Notes
   - Automatic header formatting and styling
   - Chronological data organization
4. **Configuration Requirements**:
   - Google Service Account JSON credentials
   - Spreadsheet ID for target Google Sheets document
   - Proper API permissions and sharing settings

#### Session Management:
- **State Persistence**: User session maintains current step and collected data
- **Input Validation**: Date and hours inputs are validated with error messages
- **Cancellation**: Users can cancel at any point and return to main menu

### Error Handling and Logging
Implements comprehensive logging throughout the application:
- **Structured Logging**: Centralized logging configuration with timestamp and level information
- **Exception Handling**: Try-catch blocks around critical operations with proper error logging
- **User Feedback**: Graceful error handling with user-friendly error messages

## External Dependencies

### Core Framework
- **python-telegram-bot**: Primary framework for Telegram Bot API integration, handling webhooks, message processing, and inline keyboard functionality

### Configuration Management
- **python-dotenv**: Environment variable management for secure token storage and configuration

### Google Sheets Integration
- **google-auth**: Authentication library for Google API services using service account credentials
- **google-api-python-client**: Official Google API client library for accessing Google Sheets API
- **google-auth-httplib2**: HTTP transport adapter for Google authentication

### External Services
- **Telegram Bot API**: Core messaging platform integration for receiving and sending messages
- **Google Sheets API**: Real-time data synchronization for work hour tracking and reporting
- **Central Enactus Drive**: Google Drive or similar cloud storage integration via URL links
- **Climate Survey Platform**: External survey tool integration through direct URL access

### Development Dependencies
- **logging**: Built-in Python logging for application monitoring and debugging
- **datetime**: Standard library for timestamp management and date handling
- **dataclasses**: Python data structure management for clean data modeling
- **uuid**: UUID generation for unique work hour identification

## Configuration Files

### Manager Configuration
- **Location**: `data_models.py` - `DEFAULT_MANAGERS` section (around line 200)
- **Purpose**: Define which Telegram users are managers and their managed areas/projects
- **Format**: `(telegram_user_id, "Name", ["area1", "area2"])`
- **Helper Command**: `/get_my_id` to discover user IDs
- **Documentation**: See `CONFIGURACAO_GERENTES.md` for detailed setup instructions

### Environment Variables
- **TELEGRAM_BOT_TOKEN**: Required for bot operation
- **GOOGLE_SERVICE_ACCOUNT_JSON**: Optional for Google Sheets integration
- **ENACTUS_SPREADSHEET_ID**: Optional for Google Sheets integration

### Static Configuration
- **Member List**: 28 real Enactus team members in `BotData.MEMBERS`
- **Areas**: DAF, GP, MKT, QLD, PSD in `BotData.AREAS`
- **Projects**: Odoyá, Maná, Gelé in `BotData.PROJECTS`
- **Links**: Central Drive and Climate Survey URLs in `BotData`